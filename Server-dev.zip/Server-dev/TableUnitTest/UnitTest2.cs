﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TableUnitTest
{
    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void AddAndTestData()
        {
        

        }
        [TestMethod]
        public void MyOhterTest()
        {
            //Connect to the test database
            //Client client = new Client("NLphb4HrH0", "NLphb4HrH0", "VM8GYV3qZ7");

            //Any testing you need to do
            //....
        }
    }
}
